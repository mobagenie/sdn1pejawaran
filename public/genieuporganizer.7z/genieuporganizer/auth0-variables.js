var AUTH0_CLIENT_ID='LWDEsZW1ff90xZeGebO4PpQqxiUliuCo'; 
var AUTH0_DOMAIN='mobagenie.jp.auth0.com';
// var AUTH0_CALLBACK_URL=location.href;	
var AUTH0_CALLBACK_URL= 'https://mobagenie.my.id/genieuporganizer/dashboard/';